LAZARUS — PEMBARUAN FOTO PRODUK

Repository tujuan: AzrielChoerulHakim/Lazarus_Ethereal_Scent
Branch acuan: main
Blob index.html acuan: 7722d8838cb0ba7ee8cabc9ddec9e56b884058c9

ISI PAKET
- index.html: file pengganti yang mengikuti layout, urutan produk, deskripsi,
  informasi aroma, dan tautan toko pada index.html yang sudah ada.
- assets/products/: sembilan foto pilihan terakhir pengguna, masing-masing
  dengan JPG asli, WebP ukuran asli, dan WebP lebar 600 px untuk layar kecil.

CARA MENEMPATKAN
1. Ekstrak ZIP ini.
2. Ganti index.html di root repository dengan index.html dari paket ini.
3. Tambahkan subfolder assets/products/ ke folder assets yang sudah ada.
   Jangan hapus assets/logo.png atau folder assets lama.
4. Commit dan push perubahan tersebut ke repository.

PENTING
- File assets/logo.png tetap memakai file yang SUDAH ADA di repository.
  Logo tidak disertakan atau diganti dalam paket pembaruan ini.
- Mengunggah index.html saja tanpa assets/products/ akan membuat foto tidak muncul.
- Gunakan isi ZIP, bukan ZIP-nya, sebagai file website.
- Paket ini disiapkan di sesi percakapan. Belum diunggah atau di-commit ke GitHub.

PEMETAAN PRODUK
01 Artic Wave         -> assets/products/artic-wave.jpg
02 Golden Eclipse     -> assets/products/golden-eclipse.jpg
03 Tropical Blaze     -> assets/products/tropical-blaze.jpg
04 Spring Petals      -> assets/products/spring-petals.jpg
05 Golden Charm       -> assets/products/golden-charm.jpg
06 Rouge Vanilla      -> assets/products/rouge-vanilla.jpg
07 Timeless V         -> assets/products/timeless-v.jpg
08 Midnight Illusion  -> assets/products/midnight-illusion.jpg
09 Radiant Blossom    -> assets/products/radiant-blossom.jpg

Hero: Midnight Illusion.
Preview awal: Artic Wave.

KUALITAS GAMBAR
- JPG dipertahankan identik dengan unggahan pengguna: 1143 x 2048 px.
- Tidak ada generate ulang, perubahan label/kemasan, atau pembesaran resolusi palsu.
- WebP adalah salinan untuk pengiriman yang lebih ringan, bukan foto pengganti.
- Semua foto disimpan sebagai file terpisah; tidak ada base64 dalam index.html.
- Posisi gambar di bingkai disesuaikan tanpa meregangkan proporsi botol.

INTERAKSI
- Pergantian preview memakai peralihan opacity dan skala 1.015, durasi 360 ms.
- Gambar berikutnya disiapkan dahulu sebelum mengganti gambar yang sudah tampil.
- Permintaan lama tidak dapat menimpa pilihan terbaru saat scroll/hover cepat.
- Reveal satu kali saat bagian/kartu masuk layar.
- Paralaks hero maksimal 3%, hanya desktop dengan pointer yang mendukung hover.
- Listener scroll paralaks dilepas ketika hero tidak terlihat atau tab tersembunyi.
- Pengaturan prefers-reduced-motion menonaktifkan animasi tambahan.
- HP dan tablet memakai foto di setiap kartu, tanpa preview tersembunyi yang
  ikut memuat gambar setiap pergantian produk.
- Foto produk tetap dapat dibaca melalui tampilan noscript jika JavaScript dimatikan.

PENGUJIAN
- Sintaks JavaScript diperiksa dengan node --check.
- Sembilan pergantian preview, perubahan pilihan cepat, fallback JPG,
  dan reduced-motion diuji dalam render Chromium lokal.
- Lebar 320, 390, 768, dan 1024 px: sembilan foto tampil, tanpa overflow horizontal.
- Render lokal memakai byte gambar dari paket sebagai object URL karena navigasi
  browser ke server lokal dibatasi oleh lingkungan ini. HTML yang dikirim tetap
  memakai path file relatif biasa. Path gambar juga diperiksa terhadap isi ZIP.
- Logo existing dan Google Fonts tidak tersedia dalam renderer offline.
- Website live/deployment GitHub belum diuji karena paket belum dipush.
